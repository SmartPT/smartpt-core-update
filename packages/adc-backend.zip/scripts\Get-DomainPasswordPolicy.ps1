param(
    [string] $InputJson,
    [string] $InputJsonBase64
)

$ErrorActionPreference = 'Stop'

if (-not [string]::IsNullOrWhiteSpace($InputJsonBase64)) {
    $json = [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($InputJsonBase64))
} else {
    $json = $InputJson
}

$input = $json | ConvertFrom-Json

try {
    Import-Module ActiveDirectory -ErrorAction Stop
    $policy = Get-ADDefaultDomainPasswordPolicy -ErrorAction Stop
    $result = @{
        ok = $true
        minLength = $policy.MinPasswordLength
        complexityEnabled = $policy.ComplexityEnabled
    }
} catch {
    $result = @{
        ok = $false
        error = $_.Exception.Message
    }
}

$result | ConvertTo-Json -Compress
