param(
    [string] $InputJson,
    [string] $InputJsonBase64
)

try {
    if (-not [string]::IsNullOrWhiteSpace($InputJsonBase64)) {
        $json = [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($InputJsonBase64))
    } else {
        $json = $InputJson
    }

    $input = $json | ConvertFrom-Json

    if (-not $input -or [string]::IsNullOrWhiteSpace($input.sam) -or [string]::IsNullOrWhiteSpace($input.password)) {
        $result = @{
            ok = $false
            error = "MISSING_INPUT"
        }
    } else {
        $secure = ConvertTo-SecureString $input.password -AsPlainText -Force
        Set-ADAccountPassword -Identity $input.sam -Reset -NewPassword $secure

        if ($input.mustChangeAtLogon -eq $true) {
            Set-ADUser -Identity $input.sam -ChangePasswordAtLogon $true
        }

        $result = @{
            ok = $true
            mustChangeAtLogon = $input.mustChangeAtLogon
        }
    }
} catch {
    $result = @{
        ok = $false
        error = $_.Exception.Message
    }
}

$result | ConvertTo-Json -Compress
