param(
    [string] $InputJson,
    [string] $InputJsonBase64
)

try {
    if (-not [string]::IsNullOrWhiteSpace($InputJsonBase64)) {
        $json = [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($InputJsonBase64))
    } else {
        $json = $InputJson
    }

    $input = $json | ConvertFrom-Json

    if (-not $input -or [string]::IsNullOrWhiteSpace($input.userSam) -or -not $input.groupDns) {
        $result = @{ ok = $false; error = "MISSING_INPUT" }
    } else {
        Import-Module ActiveDirectory -ErrorAction Stop
        $user = Get-ADUser -Identity $input.userSam -Properties DistinguishedName -ErrorAction Stop
        $userDn = $user.DistinguishedName

        $changed = $false
        $notDirect = @()

        foreach ($dn in $input.groupDns) {
            if ([string]::IsNullOrWhiteSpace($dn)) {
                continue
            }

            $group = Get-ADGroup -Identity $dn -Properties member -ErrorAction Stop
            $members = @($group.Member)
            $isDirectMember = $members -contains $userDn

            if ($isDirectMember) {
                Remove-ADGroupMember -Identity $dn -Members $input.userSam -Confirm:$false -ErrorAction Stop

                $verifyGroup = Get-ADGroup -Identity $dn -Properties member -ErrorAction Stop
                $verifyMembers = @($verifyGroup.Member)
                if ($verifyMembers -contains $userDn) {
                    throw "REMOVE_VERIFY_FAILED: $dn"
                }

                $changed = $true
            } else {
                $notDirect += $dn
            }
        }

        $result = @{ ok = $true; changed = $changed; notDirect = $notDirect }
    }
} catch {
    $result = @{ ok = $false; error = $_.Exception.Message }
}

$result | ConvertTo-Json -Compress
