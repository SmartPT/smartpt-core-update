param(
    [string] $InputJson,
    [string] $InputJsonBase64
)

if (-not [string]::IsNullOrWhiteSpace($InputJsonBase64)) {
    $json = [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($InputJsonBase64))
} else {
    $json = $InputJson
}

$input = $json | ConvertFrom-Json

try {
    $smtp = $input.smtp
    if (-not $smtp.enabled) {
        throw "SMTP disabled"
    }

    if ($smtp.useTls -eq $true) {
        [System.Net.ServicePointManager]::ServerCertificateValidationCallback = { $true }
    }

    $client = New-Object System.Net.Mail.SmtpClient($smtp.host, [int]$smtp.port)
    $client.EnableSsl = [bool]$smtp.useTls
    $client.Timeout = [int]($smtp.timeoutSeconds * 1000)

    if ($smtp.requireAuth -eq $true) {
        if ([string]::IsNullOrWhiteSpace([string]$smtp.username) -or [string]::IsNullOrEmpty([string]$smtp.password)) {
            throw "SMTP username or password is not configured"
        }
        $client.Credentials = New-Object System.Net.NetworkCredential([string]$smtp.username, [string]$smtp.password)
    }

    $message = New-Object System.Net.Mail.MailMessage($input.from, $input.to, $input.subject, $input.body)
    $message.IsBodyHtml = $true
    $message.BodyEncoding = [System.Text.Encoding]::UTF8
    $message.SubjectEncoding = [System.Text.Encoding]::UTF8
    $client.Send($message)

    $result = @{ ok = $true }
} catch {
    $result = @{ ok = $false; error = $_.Exception.Message }
}

$result | ConvertTo-Json -Compress
