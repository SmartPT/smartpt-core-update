param(
    [string] $InputJson,
    [string] $InputJsonBase64
)

if (-not [string]::IsNullOrWhiteSpace($InputJsonBase64)) {
    $json = [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($InputJsonBase64))
} else {
    $json = $InputJson
}

$input = $json | ConvertFrom-Json

function Get-SmtpCredential($reference) {
    if (-not $reference) { return $null }
    try {
        if (Get-Command Get-StoredCredential -ErrorAction SilentlyContinue) {
            return (Get-StoredCredential -Target $reference)
        }
    } catch { }
    return $null
}

try {
    $smtp = $input.smtp
    if (-not $smtp.enabled) {
        throw "SMTP disabled"
    }

    if ($smtp.useTls -eq $true) {
        [System.Net.ServicePointManager]::ServerCertificateValidationCallback = { $true }
    }

    $client = New-Object System.Net.Mail.SmtpClient($smtp.host, [int]$smtp.port)
    $client.EnableSsl = [bool]$smtp.useTls
    $client.Timeout = [int]($smtp.timeoutSeconds * 1000)

    if ($smtp.requireAuth -eq $true) {
        $cred = Get-SmtpCredential $smtp.credentialReference
        if (-not $cred) { throw "SMTP credentials not found" }
        $client.Credentials = New-Object System.Net.NetworkCredential($cred.Username, $cred.Password)
    }

    $message = New-Object System.Net.Mail.MailMessage($input.from, $input.to, $input.subject, $input.body)
    $client.Send($message)

    $result = @{ ok = $true }
} catch {
    $result = @{ ok = $false; error = $_.Exception.Message }
}

$result | ConvertTo-Json -Compress
