param(
    [string] $InputJson,
    [string] $InputJsonBase64
)

if (-not [string]::IsNullOrWhiteSpace($InputJsonBase64)) {
    $json = [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($InputJsonBase64))
} else {
    $json = $InputJson
}

$input = $json | ConvertFrom-Json

try {
    $policy = Get-ADDefaultDomainPasswordPolicy
    $result = @{
        ok = $true
        minLength = $policy.MinPasswordLength
        complexityEnabled = $policy.ComplexityEnabled
    }
} catch {
    $result = @{
        ok = $false
        error = $_.Exception.Message
    }
}

$result | ConvertTo-Json -Compress
