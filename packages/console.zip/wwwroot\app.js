(function () {
  const app = document.getElementById("app");
  const themeKey = "smartpt-core-theme";
  const docsUrl = "https://docs.smartpt.co.il/";
  const supportUrl = "https://smartpt.co.il/#/contact";
  const securityUrl = "https://smartpt.co.il/#/security";
  const productsUrl = "https://smartpt.co.il/#/products";

  const state = {
    theme: localStorage.getItem(themeKey) || "dark",
    auth: null,
    core: null,
    settings: null,
    activities: null,
    updates: null,
    updateBusy: null,
    groupSuggestions: { admin: [], viewer: [] },
    groupDrafts: { admin: "", viewer: "" },
    twoFactor: {
      draft: "",
      suggestions: [],
      selected: null,
      searchHint: null
    },
    publicLicense: null,
    showLicenseRecovery: false,
    activationBusy: false,
    message: null,
    currentView: "overview"
  };

  function setTheme(theme) {
    state.theme = theme;
    localStorage.setItem(themeKey, theme);
    document.documentElement.classList.toggle("theme-light", theme === "light");
  }

  async function api(path, options) {
    const response = await fetch(path, {
      credentials: "include",
      headers: {
        "Content-Type": "application/json",
        ...(options && options.headers ? options.headers : {})
      },
      ...options
    });

    const text = await response.text();
    const data = text ? JSON.parse(text) : null;

    if (!response.ok) {
      const error = new Error((data && data.message) || "Request failed.");
      error.code = data && data.code;
      error.detail = data && data.detail;
      error.status = response.status;
      error.correlationId = data && data.correlationId;
      if (response.status === 428 && error.code === "TWO_FACTOR_REQUIRED" && error.detail) {
        window.location.assign(error.detail);
        return null;
      }
      throw error;
    }

    return data;
  }

  async function loadUpdates() {
    try {
      state.updates = await api("/api/core/updates");
    } catch (error) {
      state.updates = null;
      setMessage("error", `${error.code || "UPDATE_CHECK_FAILED"} - ${error.message}${error.detail ? ` - ${error.detail}` : ""}`);
    }
  }

  async function applyProductUpdate(productKey) {
    const update = state.updates && state.updates.products
      ? state.updates.products.find((item) => item.key === productKey)
      : null;
    const name = update ? update.name : productKey;
    const confirmed = window.confirm(`Update ${name}? The updater will stop the related frontend/backend app pools, replace application files, and preserve appsettings, config, state, logs, and data.`);
    if (!confirmed) {
      return;
    }

    state.updateBusy = productKey;
    setMessage("warn", `Updating ${name}. Do not close the console until the update completes.`);
    render();

    try {
      const result = await api(`/api/core/updates/${encodeURIComponent(productKey)}/apply`, { method: "POST" });
      await loadUpdates();
      state.core = await api("/api/core/status");
      setMessage("success", `${name} updated to ${result.version}.`);
    } catch (error) {
      setMessage("error", `${error.code || "UPDATE_APPLY_FAILED"} - ${error.message}${error.detail ? ` - ${error.detail}` : ""}${error.correlationId ? ` - correlationId=${error.correlationId}` : ""}`);
      await loadUpdates().catch(() => {});
    } finally {
      state.updateBusy = null;
      render();
    }
  }

  async function fetchPublicLicenseStatus() {
    const response = await fetch("/api/auth/license", {
      credentials: "include",
      cache: "no-store"
    });

    const text = await response.text();
    let data = null;
    try {
      data = text ? JSON.parse(text) : null;
    } catch {
      data = null;
    }

    if (!response.ok) {
      const error = new Error((data && data.message) || `License check failed with ${response.status}.`);
      error.code = data && data.code;
      error.status = response.status;
      throw error;
    }

    if (!data || typeof data !== "object") {
      throw new Error("License status response was not valid JSON.");
    }

    return data;
  }

  function setMessage(type, text, detail) {
    state.message = { type, text, detail: detail || null };
  }

  function clearMessage() {
    state.message = null;
  }

  function delay(ms) {
    return new Promise((resolve) => window.setTimeout(resolve, ms));
  }

  function updateForProduct(product) {
    const rawKey = String(product && (product.key || product.name || product.title) || "").toLowerCase();
    const text = `${rawKey} ${String(product && product.name || "").toLowerCase()} ${String(product && product.title || "").toLowerCase()}`;
    const aliases = new Set([rawKey]);
    if (text.includes("jit")) {
      aliases.add("jit");
    }
    if (text.includes("adc") || text.includes("ad-control") || text.includes("ad control")) {
      aliases.add("adc");
    }

    return state.updates && state.updates.products
      ? state.updates.products.find((item) => aliases.has(String(item.key || "").toLowerCase()))
      : null;
  }

  function renderProductUpdate(product, canManageSettings) {
    const update = updateForProduct(product);
    if (!canManageSettings) {
      return "";
    }

    if (!update) {
      return `<div class="update-box"><div class="muted">Update status not loaded.</div><button class="button" type="button" id="refresh-updates">Check updates</button></div>`;
    }

    const busy = state.updateBusy === update.key;
    const pillClass = update.updateAvailable ? "warn" : "good";
    return `
      <div class="update-box">
        <div class="update-row">
          <span>Installed</span>
          <strong>${escapeHtml(update.installedVersion || "Unknown")}</strong>
        </div>
        <div class="update-row">
          <span>Latest</span>
          <strong>${escapeHtml(update.latestVersion || "Unknown")}</strong>
        </div>
        <div class="update-row">
          <span>Status</span>
          <strong class="status-pill ${pillClass}">${escapeHtml(update.status || "Unknown")}</strong>
        </div>
        ${update.lastError ? `<div class="banner error">${escapeHtml(update.lastError)}</div>` : ""}
        <button class="button primary update-action" type="button" data-update-product="${escapeHtml(update.key)}" ${update.updateAvailable && !busy ? "" : "disabled"}>${busy ? "Updating..." : "Update app"}</button>
      </div>
    `;
  }

  function productStatusClass(status) {
    return String(status || "").toLowerCase() === "active" ? "good" : "bad";
  }

  function productMeta(product) {
    const key = String(product && (product.key || product.name) || "").toLowerCase();
    if (key.includes("jit")) {
      return {
        className: "jit",
        label: "Privileged access",
        action: "Open JIT Access",
        summary: "Temporary AD group membership with role-defined duration, OTP activation, auto-removal, and audit."
      };
    }

    return {
      className: "ad-control",
      label: "AD operations",
        action: "Open AD Control",
      summary: "Tiered helpdesk actions for reset, unlock, profile, and group changes with protected identities and audit."
    };
  }

  function escapeHtml(value) {
    return String(value ?? "")
      .replaceAll("&", "&amp;")
      .replaceAll("<", "&lt;")
      .replaceAll(">", "&gt;")
      .replaceAll("\"", "&quot;")
      .replaceAll("'", "&#39;");
  }

  function formatActivityTimestamp(value) {
    if (!value) {
      return "-";
    }

    const date = new Date(value);
    if (Number.isNaN(date.getTime())) {
      return String(value);
    }

    return `${date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })} - ${date.toLocaleDateString()}`;
  }

  function formatDateTime(value, fallback = "Not available") {
    if (!value) {
      return fallback;
    }

    const date = new Date(value);
    if (Number.isNaN(date.getTime())) {
      return escapeHtml(value);
    }

    return `${date.toLocaleDateString()} ${date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}`;
  }

  function formatIdPreview(value) {
    const text = String(value || "");
    if (!text) {
      return "Not available";
    }

    if (text.length <= 12) {
      return escapeHtml(text);
    }

    return `${escapeHtml(text.slice(0, 6))}...${escapeHtml(text.slice(-6))}`;
  }

  function isLicenseFailure(error) {
    const code = String(error && error.code || "").toUpperCase();
    return (error && error.status === 403) || code.includes("LICENSE");
  }

  function formatLicenseError(error) {
    const code = String(error && error.code || "LICENSE_INVALID").toUpperCase();
    return `${code} - ${error && error.message || "License validation failed. Please contact your administrator."}`;
  }

  async function waitForActivePublicLicense(attempts = 20, delayMs = 1500) {
    let last = null;

    for (let index = 0; index < attempts; index += 1) {
      try {
        last = await fetchPublicLicenseStatus();
        if (String(last && last.status || "").toUpperCase() === "ACTIVE") {
          return last;
        }
      } catch (error) {
        last = error;
      }

      if (index < attempts - 1) {
        await delay(delayMs);
      }
    }

    throw new Error(last && (last.error || last.message) || "License activation is still applying. Wait a few seconds and try again.");
  }

  function renderLogin() {
    const licenseInactive = !!(state.showLicenseRecovery || (state.publicLicense && String(state.publicLicense.status || "").toUpperCase() !== "ACTIVE"));
    const passiveLicenseMessage = !state.message && licenseInactive && state.publicLicense && state.publicLicense.error
      ? { type: "error", text: state.publicLicense.error }
      : null;
    const banner = state.message || passiveLicenseMessage;
    app.innerHTML = `
      <div class="login-shell">
        <div class="login-card">
          <div class="login-side">
            <div class="brand">
              <img class="brand-logo" src="/smartpt-logo.png?v=20260522" alt="SmartPT">
              <div>
                <div class="eyebrow">SmartPT Core</div>
                <h1>Core Console</h1>
              </div>
            </div>
            <div style="margin-top:24px">
              <p>SmartPT Core is the enterprise entry point for SmartPT on this server. Use it to view product status, manage SmartPT Core access, and control the shared subscription settings.</p>
              <div class="footer-note">Each product portal keeps its own authentication, licensing, and operational controls. SmartPT Core stays focused on organization, visibility, and root administration.</div>
            </div>
          </div>
          <form class="login-form" id="login-form">
            <div class="top-actions" style="justify-content:flex-end">
              <button type="button" class="button" id="theme-toggle">${state.theme === "light" ? "Dark mode" : "Light mode"}</button>
              <a class="button" href="${supportUrl}" target="_blank" rel="noreferrer">Support</a>
            </div>
            <div>
              <h2>${licenseInactive ? "License Recovery" : "Sign in"}</h2>
              <p>${licenseInactive ? "Restore SmartPT Core access by purchasing a new license or activating an existing key on this server." : "Use your Active Directory account to enter the SmartPT Core console."}</p>
            </div>
            ${banner ? `<div class="banner ${banner.type}">${banner.text}${banner.detail ? `<pre class="banner-detail">${escapeHtml(banner.detail)}</pre>` : ""}</div>` : ""}
            ${licenseInactive ? `
              <section class="license-recovery-panel">
                <div class="license-recovery-header">
                  <span class="license-recovery-kicker">License Recovery</span>
                  <h3>Restore SmartPT access</h3>
                  <p>Your SmartPT subscription is not active. Purchase a new license or activate an existing license key on this server.</p>
                </div>
                <div class="license-recovery-actions">
                  <a class="button" href="${escapeHtml(state.publicLicense.buyLicenseUrl || "https://www.smartpt.co.il/pages/smartpt_core_checkout.html")}" target="_blank" rel="noreferrer">Buy license</a>
                  <div class="license-recovery-activate">
                    <input class="input license-recovery-input" id="license-key" placeholder="Enter license key" ${state.activationBusy ? "disabled" : ""}>
                    <button class="button primary" type="button" id="activate-license" ${state.activationBusy ? "disabled" : ""}>${state.activationBusy ? "Activating..." : "Activate License"}</button>
                  </div>
                </div>
                <div class="license-recovery-note">Activation updates the installed SmartPT configuration and reloads the portal automatically.</div>
              </section>
            ` : `
            <div class="field">
              <label for="username">Username</label>
              <input class="input" id="username" autocomplete="username" placeholder="DOMAIN\\samAccountName or user@domain">
            </div>
            <div class="field">
              <label for="password">Password</label>
              <input class="input" id="password" type="password" autocomplete="current-password" placeholder="Password">
            </div>
            <button class="button primary" type="submit">Sign in</button>
            `}
            <div class="footer-note">Session expiry on the SmartPT Core console requires a new sign-in. Product portals continue using their own independent session controls.</div>
          </form>
        </div>
      </div>
    `;

    document.querySelectorAll("[data-update-product]").forEach((button) => {
      button.onclick = async (event) => {
        event.preventDefault();
        event.stopPropagation();
        await applyProductUpdate(button.dataset.updateProduct);
      };
    });

    const refreshUpdatesButton = document.getElementById("refresh-updates");
    if (refreshUpdatesButton) {
      refreshUpdatesButton.onclick = async () => {
        await loadUpdates();
        render();
      };
    }
    document.getElementById("theme-toggle").onclick = () => {
      setTheme(state.theme === "light" ? "dark" : "light");
      render();
    };

    document.getElementById("login-form").onsubmit = async (event) => {
      event.preventDefault();
      if (licenseInactive) {
        return;
      }
      clearMessage();
      state.showLicenseRecovery = false;
      const username = document.getElementById("username").value.trim();
      const password = document.getElementById("password").value;

      try {
        await api("/api/auth/login", {
          method: "POST",
          body: JSON.stringify({ username, password })
        });
        const authStatus = await api("/api/auth/status");
        if (authStatus && authStatus.requiresTwoFactor && authStatus.twoFactorUrl) {
          window.location.assign(authStatus.twoFactorUrl);
          return;
        }
        await bootstrapAuthenticated();
      } catch (error) {
        if (isLicenseFailure(error)) {
          state.showLicenseRecovery = true;
          setMessage("error", `${formatLicenseError(error)}${error.correlationId ? ` - correlationId=${error.correlationId}` : ""}`);
        } else {
          setMessage("error", `${error.code || "LOGIN_FAILED"} - ${error.message}${error.correlationId ? ` - correlationId=${error.correlationId}` : ""}`);
        }
        render();
      }
    };

    const activateButton = document.getElementById("activate-license");
    if (activateButton) {
      activateButton.onclick = async () => {
        if (state.activationBusy) {
          return;
        }

        try {
          const licenseKey = (document.getElementById("license-key")?.value || "").trim();
          if (!licenseKey) {
            setMessage("error", "LICENSE_KEY_REQUIRED - License key is required.");
            render();
            return;
          }

          state.activationBusy = true;
          setMessage("warn", "Activating license and updating the server configuration...");
          render();
          const response = await api("/api/auth/license/activate", {
            method: "POST",
            body: JSON.stringify({ licenseKey })
          });
          setMessage("warn", response.message || "Activation completed. Verifying license...", response.detail || null);
          state.publicLicense = await waitForActivePublicLicense(30, 2000);
          state.showLicenseRecovery = false;
          setMessage("success", "License activation completed. Sign in to continue.");
        } catch (error) {
          setMessage(
            "error",
            `${error.code || "LICENSE_ACTIVATION_FAILED"} - ${error.message}${error.correlationId ? ` - correlationId=${error.correlationId}` : ""}`,
            error.detail || null
          );
        } finally {
          state.activationBusy = false;
          render();
        }
      };
    }
  }

  function renderOverview(core) {
    const canManageSettings = !!core.canManageSettings;
    return `
      <div class="grid">
        <section class="panel span-12 control-map">
          <div class="panel-head">
            <div>
              <div class="eyebrow">Architecture</div>
              <h2>One server entry point for controlled AD operations</h2>
            </div>
            <span class="status-pill good">On-prem</span>
          </div>
          <p>SmartPT Core keeps the shared license, root access, two-factor recovery, product visibility, and support links in one place. JIT and AD Control remain separate consoles for privileged actions.</p>
        </section>
        <section class="panel span-12">
          <div class="panel-head">
            <div>
              <div class="eyebrow">Products</div>
              <h2>Installed product consoles</h2>
            </div>
          </div>
          <p>Open the product console that matches the operation. AD Control handles tiered helpdesk actions. JIT handles temporary privileged access.</p>
          <div class="product-grid">
            ${core.products.map((product) => {
              const meta = productMeta(product);
              return `
              <article class="product-card product-card-${meta.className}">
                <div class="product-card-head">
                  <div>
                    <div class="product-kicker">${meta.label}</div>
                    <h3>${escapeHtml(product.name)}</h3>
                  </div>
                  <span class="status-pill ${productStatusClass(product.status)}">${escapeHtml(product.status)}</span>
                </div>
                <p>${escapeHtml(product.description || meta.summary)}</p>
                <div class="muted">${escapeHtml(product.statusDetail || meta.summary)}</div>
                ${renderProductUpdate(product, canManageSettings)}
                <a class="product-link" href="${escapeHtml(product.url)}">${meta.action}</a>
              </article>
            `}).join("")}
          </div>
        </section>
      </div>
    `;
  }

  function renderGroupManager(idPrefix, label, values, suggestions) {
    const kind = idPrefix === "admin-groups" ? "admin" : "viewer";
    const draftValue = state.groupDrafts[kind] || "";
    return `
      <div class="field group-manager">
        <label for="${idPrefix}-input">${label}</label>
        <div class="group-entry">
          <input class="input" id="${idPrefix}-input" list="${idPrefix}-list" placeholder="Search Active Directory groups" value="${escapeHtml(draftValue)}" autocomplete="off">
          <button class="button" type="button" id="${idPrefix}-add">Add</button>
        </div>
        <datalist id="${idPrefix}-list">
          ${suggestions.map((item) => `<option value="${escapeHtml(item)}"></option>`).join("")}
        </datalist>
        <div class="muted suggestion-hint" id="${idPrefix}-hint">${suggestions.length > 0 ? "Select a suggested Active Directory group, then click Add." : "Start typing at least two characters to search Active Directory groups."}</div>
        <div class="group-chip-list" id="${idPrefix}-chips">
          ${values.length === 0
            ? `<div class="muted">No groups added.</div>`
            : values.map((item) => `
                <div class="group-chip">
                  <span>${escapeHtml(item)}</span>
                  <button type="button" data-remove-group="${idPrefix}" data-remove-value="${escapeHtml(item)}">Remove</button>
                </div>
              `).join("")}
        </div>
      </div>
    `;
  }

  function renderSettings(core) {
    const settings = state.settings.settings;
    const twoFactorUser = state.twoFactor.selected;
    return `
      <div class="grid">
        <section class="panel span-8">
          <div class="panel-head">
            <div>
              <div class="eyebrow">Settings</div>
              <h2>Portal Access Settings</h2>
            </div>
          </div>
          <p>Domain Admins always retain administrative access. Add approved Active Directory groups below to extend SmartPT Core access to additional administrators or viewers for the root console.</p>
          <div class="field-grid" style="margin-top:18px">
            ${renderGroupManager("admin-groups", "Administrative groups", settings.administrativeGroups || [], state.groupSuggestions.admin || [])}
            ${renderGroupManager("viewer-groups", "Viewer groups", settings.viewerGroups || [], state.groupSuggestions.viewer || [])}
          </div>
          <div class="field-grid compact-grid" style="margin-top:18px">
            <div class="field">
              <label for="max-hours">Maximum session lifetime (hours)</label>
              <input class="input" id="max-hours" type="number" min="1" max="24" value="${settings.session.maxSessionHours}">
            </div>
            <div class="field">
              <label for="idle-minutes">Idle timeout (minutes)</label>
              <input class="input" id="idle-minutes" type="number" min="5" max="60" value="${settings.session.idleTimeoutMinutes}">
            </div>
          </div>
          <div class="muted" style="margin-top:12px">These limits are enforced server-side on SmartPT Core only. Product portals keep their own separate session configuration.</div>
          <div class="settings-actions">
            <button class="button primary" id="save-settings">Save settings</button>
          </div>
        </section>
        <section class="panel span-8">
          <div class="panel-head">
            <div>
              <div class="eyebrow">Security</div>
              <h2>Shared Two-Factor Access</h2>
            </div>
          </div>
          <p>Manage shared SmartPT two-factor enrollment from the root console. Reset a user only when the authenticator is lost or re-enrollment is required.</p>
          <div class="field group-manager" style="margin-top:18px">
            <label for="twofactor-user-input">User</label>
            <div class="group-entry">
              <input class="input" id="twofactor-user-input" list="twofactor-user-list" placeholder="Search Active Directory users" value="${escapeHtml(state.twoFactor.draft || "")}" autocomplete="off">
              <button class="button" type="button" id="twofactor-user-search">Search</button>
            </div>
            <datalist id="twofactor-user-list">
              ${(state.twoFactor.suggestions || []).map((item) => `<option value="${escapeHtml(item.principal)}">${escapeHtml(item.displayName)}</option>`).join("")}
            </datalist>
            <div class="muted suggestion-hint" id="twofactor-user-hint">${state.twoFactor.searchHint || ((state.twoFactor.suggestions || []).length > 0 ? "Select a result or search again." : "Start typing at least two characters to search Active Directory users.")}</div>
          </div>
          ${(state.twoFactor.suggestions || []).length > 0 ? `
            <div class="twofactor-search-results">
              ${(state.twoFactor.suggestions || []).map((item) => `
                <button class="twofactor-search-result" type="button" data-twofactor-user="${escapeHtml(item.principal)}">
                  <span class="twofactor-search-name">${escapeHtml(item.displayName)}</span>
                  <span class="twofactor-search-principal">${escapeHtml(item.principal)}</span>
                </button>
              `).join("")}
            </div>
          ` : ``}
          ${twoFactorUser ? `
            <div class="twofactor-card">
              <div class="twofactor-card-head">
                <div>
                  <div class="stat-label">Selected user</div>
                  <div class="stat-value stat-value-small">${escapeHtml(twoFactorUser.user.displayName)}</div>
                  <div class="muted mono">${escapeHtml(twoFactorUser.user.principal)}</div>
                </div>
                <span class="status-pill ${twoFactorUser.twoFactor.enrolled ? "good" : "warn"}">${twoFactorUser.twoFactor.enrolled ? "Enrolled" : "Not enrolled"}</span>
              </div>
              <div class="field-grid compact-grid" style="margin-top:18px">
                <div class="stat">
                  <div class="stat-label">Status</div>
                  <div class="muted">${twoFactorUser.twoFactor.enrolled ? "Enrolled" : "Not enrolled"}</div>
                </div>
                <div class="stat">
                  <div class="stat-label">Enrolled at</div>
                  <div class="muted">${formatDateTime(twoFactorUser.twoFactor.enrolledAtUtc, "Not enrolled")}</div>
                </div>
                <div class="stat">
                  <div class="stat-label">Last verified</div>
                  <div class="muted">${formatDateTime(twoFactorUser.twoFactor.lastVerifiedUtc, "No verification recorded")}</div>
                </div>
              </div>
              <div class="twofactor-action-block">
                <div class="stat-label">Available action</div>
                <div class="muted">${twoFactorUser.twoFactor.resetRequiredAfterUtc ? `Reset requested ${formatDateTime(twoFactorUser.twoFactor.resetRequiredAfterUtc)}. The user must enroll again on the next sign-in.` : "Reset two-factor to clear the current enrollment and require setup again on the next sign-in."}</div>
              </div>
              <div class="settings-actions">
                <button class="button danger" type="button" id="twofactor-reset">Reset two-factor</button>
              </div>
            </div>
          ` : `
            <div class="muted" style="margin-top:18px">Select a user to view shared two-factor status.</div>
          `}
        </section>
        <section class="panel span-4">
          <div class="eyebrow">License And Billing</div>
          <h2 style="margin-top:8px">SmartPT Core</h2>
          <div class="card-stack" style="margin-top:18px">
            <div class="stat">
              <div class="stat-label">Status</div>
              <div class="stat-value stat-value-small">${core.license.status}</div>
            </div>
            <div class="stat">
              <div class="stat-label">Serial</div>
              <div class="muted mono" title="${escapeHtml(core.license.serial || "")}">${escapeHtml(core.license.serial || "Not available")}</div>
            </div>
            <div class="stat">
              <div class="stat-label">Last validated</div>
              <div class="muted">${formatDateTime(core.license.lastValidatedUtc, "Not validated yet")}</div>
            </div>
            <div class="action-card static">
              <h3>Documentation</h3>
              <p>Installation, administration, security policy, and release material are maintained centrally for SmartPT operators.</p>
              <div class="link-stack">
                <a class="github-link" href="${docsUrl}" target="_blank" rel="noreferrer">Open SmartPT documentation</a>
                <a class="github-link" href="${securityUrl}" target="_blank" rel="noreferrer">Open security page</a>
              </div>
            </div>
            <div class="danger-zone">
              <div>
                <h3>Subscription cancellation</h3>
                <p>Stops the shared SmartPT Core subscription for this server after confirmation.</p>
              </div>
              <button class="button danger" id="cancel-core-license">Cancel SmartPT Core license</button>
            </div>
          </div>
        </section>
      </div>
    `;
  }

  function renderActivity() {
    return `
      <div class="grid">
        <section class="panel span-12">
          <div class="panel-head">
            <div>
              <div class="eyebrow">Recent Activity</div>
              <h2>Administrative Activity</h2>
            </div>
            <button class="button" id="refresh-activity">${state.activities ? "Refresh" : "Load activity"}</button>
          </div>
          <p>Last 24 hours only. Up to 20 meaningful administrative actions are shown here.</p>
          <div class="activity-list">
            ${(state.activities && state.activities.length > 0)
              ? state.activities.map((entry) => `
                <article class="activity-item">
                  <div class="activity-meta">
                    <span class="status-pill ${entry.result === "success" ? "good" : "bad"}"><span class="status-dot"></span>${entry.result === "success" ? "Completed" : "Attention"}</span>
                    <span>${formatActivityTimestamp(entry.timestampUtc)}</span>
                    <span>${entry.product}</span>
                    <span>${entry.actor}</span>
                  </div>
                  <div class="activity-description">${entry.description}</div>
                  <div class="activity-meta">
                    <span>${entry.target ? `Target: ${entry.target}` : "No direct target"}</span>
                    <span class="mono" title="${escapeHtml(entry.correlationId || "")}">Correlation: ${formatIdPreview(entry.correlationId)}</span>
                  </div>
                </article>
              `).join("")
              : `<div class="muted">${state.activities ? "No recent administrative activity is available." : "Load recent activity to view the latest actions across SmartPT Core and the product portals."}</div>`}
          </div>
        </section>
      </div>
    `;
  }

  function renderApp() {
    const core = state.core;
    const canManageSettings = !!core.canManageSettings;
    const tabs = [["overview", "Overview"]];

    if (canManageSettings) {
      tabs.push(["activity", "Recent Activity"]);
      tabs.push(["settings", "Settings"]);
    }

    const active = tabs.some(([key]) => key === state.currentView) ? state.currentView : "overview";
    const contentHtml =
      active === "settings" ? renderSettings(core) :
      active === "activity" ? renderActivity() :
      renderOverview(core);

    app.innerHTML = `
      <div class="shell">
        <header class="header">
          <div class="brand">
            <img class="brand-logo" src="/smartpt-logo.png?v=20260522" alt="SmartPT">
            <div>
              <div class="eyebrow">SmartPT Core</div>
              <h1>Core Console</h1>
              <div class="muted">On-prem control plane for SmartPT licensing, root access, shared 2FA, and product visibility.</div>
            </div>
          </div>
          <div class="top-actions">
            <a class="button" href="${productsUrl}" target="_blank" rel="noreferrer">Products</a>
            <a class="button" href="${docsUrl}" target="_blank" rel="noreferrer">Docs</a>
            <a class="button" href="${supportUrl}" target="_blank" rel="noreferrer">Support</a>
            <button class="button" id="theme-toggle">${state.theme === "light" ? "Dark mode" : "Light mode"}</button>
            <button class="button" id="sign-out">Sign out</button>
          </div>
        </header>

        ${state.message ? `<div class="banner ${state.message.type}">${state.message.text}</div>` : ""}

        <section class="hero">
          <div class="panel">
            <div class="eyebrow">On-prem control plane</div>
            <h2>SmartPT Core is active on this server</h2>
            <p>Use this console to manage root access, shared 2FA, license status, and product visibility. JIT and AD Control keep privileged actions inside dedicated product consoles.</p>
            <div class="stats">
              <div class="stat">
                <div class="stat-label">Products</div>
                <div class="stat-value">${core.products.length}</div>
              </div>
              <div class="stat">
                <div class="stat-label">User</div>
                <div class="stat-value stat-value-small">${core.displayName}</div>
              </div>
              <div class="stat">
                <div class="stat-label">Access</div>
                <div class="stat-value stat-value-small">${core.accessLevel}</div>
              </div>
            </div>
          </div>
        </section>

        <div class="tabs" role="tablist" aria-label="SmartPT Core sections">
          ${tabs.map(([key, label]) => `<button type="button" class="tab ${active === key ? "active" : ""}" data-tab="${key}" role="tab" aria-selected="${active === key ? "true" : "false"}">${label}</button>`).join("")}
        </div>

        ${contentHtml}
      </div>
    `;

    document.querySelectorAll("[data-tab]").forEach((tab) => {
      tab.onclick = async () => {
        state.currentView = tab.dataset.tab;
        if (state.currentView === "settings" && !state.settings) {
          await loadSettings();
          return;
        }
        if (state.currentView === "activity" && !state.activities) {
          await loadRecentActivity();
          render();
          return;
        }
        render();
      };
    });

    document.querySelectorAll("[data-update-product]").forEach((button) => {
      button.onclick = async (event) => {
        event.preventDefault();
        event.stopPropagation();
        await applyProductUpdate(button.dataset.updateProduct);
      };
    });

    const refreshUpdatesButton = document.getElementById("refresh-updates");
    if (refreshUpdatesButton) {
      refreshUpdatesButton.onclick = async () => {
        await loadUpdates();
        render();
      };
    }
    document.getElementById("theme-toggle").onclick = () => {
      setTheme(state.theme === "light" ? "dark" : "light");
      render();
    };

    document.getElementById("sign-out").onclick = async () => {
      await api("/api/auth/logout", { method: "POST" }).catch(() => {});
      state.auth = null;
      state.core = null;
      state.settings = null;
      state.activities = null;
      state.updates = null;
      clearMessage();
      render();
    };

    const saveButton = document.getElementById("save-settings");
    if (saveButton) {
      saveButton.onclick = async () => {
        try {
      const body = {
        administrativeGroups: state.settings.settings.administrativeGroups || [],
        viewerGroups: state.settings.settings.viewerGroups || [],
        maxSessionHours: Number(document.getElementById("max-hours").value || 24),
        idleTimeoutMinutes: Number(document.getElementById("idle-minutes").value || 60)
          };

      state.settings = await api("/api/core/settings", {
        method: "POST",
        body: JSON.stringify(body)
      });
      state.groupDrafts = { admin: "", viewer: "" };
      state.groupSuggestions = { admin: [], viewer: [] };
      state.core = await api("/api/core/status");
      await loadRecentActivity();
      setMessage("success", "SmartPT Core settings saved successfully.");
          render();
        } catch (error) {
          setMessage("error", `${error.code || "SAVE_FAILED"} - ${error.message}${error.detail ? ` - ${error.detail}` : ""}${error.correlationId ? ` - correlationId=${error.correlationId}` : ""}`);
          render();
        }
      };
    }

    wireGroupManager("admin-groups", "admin", "administrativeGroups");
    wireGroupManager("viewer-groups", "viewer", "viewerGroups");
    wireTwoFactorManager();

    const cancelButton = document.getElementById("cancel-core-license");
    if (cancelButton) {
      cancelButton.onclick = async () => {
        const confirmed = window.confirm("Cancel the SmartPT Core subscription for this server?");
        if (!confirmed) {
          return;
        }

        try {
          const response = await api("/api/core/license/cancel", { method: "POST" });
          state.core = await api("/api/core/status");
          await loadRecentActivity();
          const suffix = response.approvalUrl ? " Complete the external approval step if one was opened." : "";
          if (response.approvalUrl) {
            window.open(response.approvalUrl, "_blank", "noopener,noreferrer");
          }
          setMessage("success", `${response.message || "Cancellation request submitted."}${suffix}`);
          render();
        } catch (error) {
          setMessage("error", `${error.code || "LICENSE_CANCEL_FAILED"} - ${error.message}${error.correlationId ? ` - correlationId=${error.correlationId}` : ""}`);
          render();
        }
      };
    }

    const refreshActivityButton = document.getElementById("refresh-activity");
    if (refreshActivityButton) {
      refreshActivityButton.onclick = async () => {
        await loadRecentActivity();
        render();
      };
    }
  }

  async function loadSettings() {
    try {
      const settings = await api("/api/core/settings");
      state.settings = settings;
      state.groupSuggestions = { admin: [], viewer: [] };
      state.twoFactor = { draft: "", suggestions: [], selected: null, searchHint: null };
      render();
    } catch (error) {
      setMessage("error", `${error.code || "LOAD_FAILED"} - ${error.message}${error.correlationId ? ` - correlationId=${error.correlationId}` : ""}`);
      state.currentView = "overview";
      render();
    }
  }

  async function loadRecentActivity() {
    try {
      const activity = await api("/api/core/activity/recent?limit=30");
      state.activities = activity.activities || [];
    } catch (error) {
      setMessage("error", `${error.code || "LOAD_FAILED"} - ${error.message}${error.correlationId ? ` - correlationId=${error.correlationId}` : ""}`);
      state.currentView = "overview";
    }
  }

  function parseLines(value) {
    return value.split("\n").map((line) => line.trim()).filter(Boolean);
  }

  async function searchGroups(kind, query) {
    const idPrefix = kind === "admin" ? "admin-groups" : "viewer-groups";
    if (!query || query.trim().length < 2) {
      state.groupSuggestions[kind] = [];
      updateSuggestionList(idPrefix, kind);
      return;
    }

    try {
      const response = await api(`/api/core/groups/search?q=${encodeURIComponent(query.trim())}`);
      state.groupSuggestions[kind] = response.results || [];
      updateSuggestionList(idPrefix, kind);
    } catch {
      state.groupSuggestions[kind] = [];
      updateSuggestionList(idPrefix, kind);
    }
  }

  async function searchTwoFactorUsers(query) {
    if (!query || query.trim().length < 2) {
      state.twoFactor.suggestions = [];
      state.twoFactor.searchHint = "Start typing at least two characters to search Active Directory users.";
      updateTwoFactorSuggestionList();
      return;
    }

    try {
      const response = await api(`/api/core/users/search?q=${encodeURIComponent(query.trim())}`);
      state.twoFactor.suggestions = response.results || [];
      state.twoFactor.searchHint = (state.twoFactor.suggestions || []).length > 0
        ? "Select a result or search again."
        : "No matching Active Directory users were found.";
      updateTwoFactorSuggestionList();
    } catch {
      state.twoFactor.suggestions = [];
      state.twoFactor.searchHint = "Active Directory user search failed.";
      updateTwoFactorSuggestionList();
    }
  }

  function updateSuggestionList(idPrefix, kind) {
    const list = document.getElementById(`${idPrefix}-list`);
    const hint = document.getElementById(`${idPrefix}-hint`);
    if (!list) {
      return;
    }

    const suggestions = state.groupSuggestions[kind] || [];
    list.innerHTML = suggestions.map((item) => `<option value="${escapeHtml(item)}"></option>`).join("");
    if (hint) {
      hint.textContent = suggestions.length > 0
        ? "Select a suggested Active Directory group, then click Add."
        : "Start typing at least two characters to search Active Directory groups.";
    }
  }

  function updateTwoFactorSuggestionList() {
    const list = document.getElementById("twofactor-user-list");
    const hint = document.getElementById("twofactor-user-hint");
    if (!list) {
      return;
    }

    const suggestions = state.twoFactor.suggestions || [];
    list.innerHTML = suggestions.map((item) => `<option value="${escapeHtml(item.principal)}">${escapeHtml(item.displayName)}</option>`).join("");
    if (hint) {
      hint.textContent = state.twoFactor.searchHint || (suggestions.length > 0
        ? "Select a result or search again."
        : "Start typing at least two characters to search Active Directory users.");
    }
  }

  function wireGroupManager(idPrefix, kind, settingKey) {
    const input = document.getElementById(`${idPrefix}-input`);
    const addButton = document.getElementById(`${idPrefix}-add`);
    if (!input || !addButton || !state.settings) {
      return;
    }

    const addValue = (value) => {
      const normalized = String(value || "").trim();
      if (!normalized) {
        return;
      }

      const suggestions = state.groupSuggestions[kind] || [];
      const matched = suggestions.find((item) => item.toLowerCase() === normalized.toLowerCase());
      if (!matched) {
        setMessage("error", `GROUP_NOT_VALIDATED - Select a valid Active Directory group from the suggested results before adding it.`);
        render();
        return;
      }

      const current = state.settings.settings[settingKey] || [];
      if (!current.some((item) => String(item).toLowerCase() === matched.toLowerCase())) {
        state.settings.settings[settingKey] = [...current, matched];
      }
      state.groupDrafts[kind] = "";
      clearMessage();
      state.groupSuggestions[kind] = [];
      render();
    };

    input.oninput = () => {
      state.groupDrafts[kind] = input.value;
      searchGroups(kind, input.value);
    };

    input.onkeydown = (event) => {
      if (event.key === "Enter") {
        event.preventDefault();
        const suggestion = (state.groupSuggestions[kind] || [])[0];
        addValue(suggestion || state.groupDrafts[kind]);
      }
    };

    addButton.onclick = () => {
      const suggestion = (state.groupSuggestions[kind] || []).find((item) => item.toLowerCase() === String(state.groupDrafts[kind] || "").trim().toLowerCase());
      addValue(suggestion || state.groupDrafts[kind]);
    };

    updateSuggestionList(idPrefix, kind);

    document.querySelectorAll(`[data-remove-group="${idPrefix}"]`).forEach((button) => {
      button.onclick = () => {
        const value = button.dataset.removeValue;
        state.settings.settings[settingKey] = (state.settings.settings[settingKey] || []).filter((item) => String(item).toLowerCase() !== String(value).toLowerCase());
        render();
      };
    });
  }

  function wireTwoFactorManager() {
    const input = document.getElementById("twofactor-user-input");
    const searchButton = document.getElementById("twofactor-user-search");
    const resetButton = document.getElementById("twofactor-reset");

    if (input && searchButton) {
      const loadUser = async (principal) => {
        state.twoFactor.selected = await api(`/api/core/twofactor/user?principal=${encodeURIComponent(principal)}`);
        clearMessage();
        render();
      };

      const searchSelected = async () => {
        const normalized = String(state.twoFactor.draft || "").trim();
        if (!normalized) {
          return;
        }

        try {
          const response = await api(`/api/core/users/search?q=${encodeURIComponent(normalized)}`);
          const results = response.results || [];
          state.twoFactor.suggestions = results;

          const matched = results.find((item) =>
            item.principal.toLowerCase() === normalized.toLowerCase()
            || item.samAccountName.toLowerCase() === normalized.toLowerCase()
            || item.displayName.toLowerCase() === normalized.toLowerCase());

          if (matched) {
            await loadUser(matched.principal);
            return;
          }

          if (results.length === 1) {
            await loadUser(results[0].principal);
            return;
          }

          state.twoFactor.searchHint = results.length === 0
            ? "No matching Active Directory users were found."
            : "Select one of the matching users below.";
          state.twoFactor.selected = null;
          clearMessage();
          render();
        } catch (error) {
          setMessage("error", `${error.code || "TWO_FACTOR_LOOKUP_FAILED"} - ${error.message}${error.correlationId ? ` - correlationId=${error.correlationId}` : ""}`);
          render();
        }
      };

      input.oninput = () => {
        state.twoFactor.draft = input.value;
        searchTwoFactorUsers(input.value);
      };

      input.onkeydown = (event) => {
        if (event.key === "Enter") {
          event.preventDefault();
          searchSelected();
        }
      };

      searchButton.onclick = searchSelected;
      updateTwoFactorSuggestionList();

      document.querySelectorAll("[data-twofactor-user]").forEach((button) => {
        button.onclick = async () => {
          try {
            await loadUser(button.dataset.twofactorUser);
          } catch (error) {
            setMessage("error", `${error.code || "TWO_FACTOR_LOOKUP_FAILED"} - ${error.message}${error.correlationId ? ` - correlationId=${error.correlationId}` : ""}`);
            render();
          }
        };
      });
    }

    if (resetButton && state.twoFactor.selected) {
      resetButton.onclick = async () => {
        const confirmed = window.confirm(`Reset shared two-factor for ${state.twoFactor.selected.user.displayName}?`);
        if (!confirmed) {
          return;
        }

        try {
          await api("/api/core/twofactor/reset", {
            method: "POST",
            body: JSON.stringify({ principal: state.twoFactor.selected.user.principal })
          });
          state.twoFactor.selected = await api(`/api/core/twofactor/user?principal=${encodeURIComponent(state.twoFactor.selected.user.principal)}`);
          setMessage("success", "Two-factor access was reset. The user must enroll again on the next sign-in.");
          render();
        } catch (error) {
          setMessage("error", `${error.code || "TWO_FACTOR_RESET_FAILED"} - ${error.message}${error.correlationId ? ` - correlationId=${error.correlationId}` : ""}`);
          render();
        }
      };
    }
  }

  async function loadRecentActivity() {
    try {
      const response = await api("/api/core/activity/recent?limit=30");
      state.activities = response.activities || [];
    } catch (error) {
      setMessage("error", `${error.code || "ACTIVITY_LOAD_FAILED"} - ${error.message}${error.correlationId ? ` - correlationId=${error.correlationId}` : ""}`);
    }
  }

  async function bootstrapAuthenticated() {
    try {
      state.auth = await api("/api/auth/status");
      if (state.auth && state.auth.requiresTwoFactor && state.auth.twoFactorUrl) {
        window.location.assign(state.auth.twoFactorUrl);
        return;
      }
      state.showLicenseRecovery = false;
      if (!state.auth.authenticated) {
        state.core = null;
        state.settings = null;
        state.activities = null;
        render();
        return;
      }

      state.core = await api("/api/core/status");
      if (state.core && state.core.canManageSettings) {
        await loadUpdates();
      }
      clearMessage();
      render();
    } catch (error) {
      if (error.status === 401 || error.code === "SESSION_UNAUTHENTICATED") {
        state.auth = null;
        state.core = null;
        state.settings = null;
        setMessage("error", "Session expired. Please sign in again.");
        render();
        return;
      }

      setMessage("error", `${error.code || "APPLICATION_ERROR"} - ${error.message}${error.correlationId ? ` - correlationId=${error.correlationId}` : ""}`);
      render();
    }
  }

  async function boot() {
    try {
      state.auth = await api("/api/auth/status");
      if (state.auth.authenticated) {
        await bootstrapAuthenticated();
        return;
      }
      state.showLicenseRecovery = false;
    } catch {
      // fall back to login rendering
    }

    try {
      state.publicLicense = await fetchPublicLicenseStatus();
      state.showLicenseRecovery = String(state.publicLicense && state.publicLicense.status || "").toUpperCase() !== "ACTIVE";
    } catch {
      state.publicLicense = null;
      state.showLicenseRecovery = false;
    }

    render();
  }

  function render() {
    setTheme(state.theme);
    if (!state.auth || !state.auth.authenticated || !state.core) {
      renderLogin();
      return;
    }
    renderApp();
  }

  boot();
})();





