param(
    [string] $InputJson,
    [string] $InputJsonBase64
)

try {
    Import-Module ActiveDirectory -ErrorAction Stop

    if (-not [string]::IsNullOrWhiteSpace($InputJsonBase64)) {
        $json = [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($InputJsonBase64))
    } else {
        $json = $InputJson
    }

    $input = $json | ConvertFrom-Json

    if (-not $input -or [string]::IsNullOrWhiteSpace($input.sam)) {
        $result = @{
            ok = $false
            error = "MISSING_INPUT"
        }
    } else {
        $user = Get-ADUser -Identity $input.sam -Properties Enabled -ErrorAction Stop
        if (-not $user.Enabled) {
            $result = @{
                ok = $true
                alreadyDisabled = $true
            }
        } else {
            Disable-ADAccount -Identity $input.sam -ErrorAction Stop
            $result = @{
                ok = $true
            }
        }
    }
} catch {
    $result = @{
        ok = $false
        error = $_.Exception.Message
    }
}

$result | ConvertTo-Json -Compress
