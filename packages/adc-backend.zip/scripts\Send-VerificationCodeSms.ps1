param(
    [string] $InputJson,
    [string] $InputJsonBase64
)

if (-not [string]::IsNullOrWhiteSpace($InputJsonBase64)) {
    $json = [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($InputJsonBase64))
} else {
    $json = $InputJson
}

$input = $json | ConvertFrom-Json
$debugPath = Join-Path (Split-Path -Parent $PSScriptRoot) "logs\sms-debug.jsonl"

function Write-SmsDebug($stage, $data) {
    try {
        $entry = @{
            timestampUtc = [DateTimeOffset]::UtcNow.ToString("O")
            stage = $stage
            data = $data
        } | ConvertTo-Json -Compress -Depth 6
        Add-Content -LiteralPath $debugPath -Value $entry -Encoding UTF8
    } catch { }
}

Write-SmsDebug "input" @{
    raw = $json
    phone = $input.phone
    name = $input.name
    otpLength = if ($input.otp) { ([string]$input.otp).Length } else { 0 }
}

try {
    if ([string]::IsNullOrWhiteSpace($input.phone)) {
        throw "Phone is required."
    }

    if ([string]::IsNullOrWhiteSpace($input.otp)) {
        throw "OTP is required."
    }

    $payload = @{
        phone = [string]$input.phone
        name = [string]$input.name
        otp = [string]$input.otp
    } | ConvertTo-Json -Compress

    $response = Invoke-RestMethod `
        -Uri "https://plans.smartpt.co.il/message" `
        -Method Post `
        -ContentType "application/json" `
        -Body $payload `
        -TimeoutSec 30

    Write-SmsDebug "provider-response" $response

    $status = [string]$response.status
    $successStatuses = @("sent", "queued", "accepted", "ok", "success")
    if ($successStatuses -notcontains $status.ToLowerInvariant()) {
        $reason = [string]$response.reason
        if ([string]::IsNullOrWhiteSpace($reason)) {
            $reason = "Unexpected message API status '$status'."
        }

        throw $reason
    }

    $result = @{
        Sent = $true
        Ok = $true
        Success = $true
        Status = $status
    }
} catch {
    $result = @{
        Sent = $false
        Ok = $false
        Success = $false
        Error = $_.Exception.Message
    }
}

Write-SmsDebug "result" $result
$result | ConvertTo-Json -Compress
