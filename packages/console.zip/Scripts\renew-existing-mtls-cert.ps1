param(
    [Parameter(Mandatory = $true)]
    [string]$Serial,

    [Parameter(Mandatory = $true)]
    [string]$CurrentThumbprint,

    [Parameter(Mandatory = $true)]
    [string]$RenewUrl,

    [ValidateSet("CurrentUser", "LocalMachine")]
    [string]$StoreLocation = "LocalMachine",

    [string]$StoreName = "My",

    [int]$RequestTimeoutSeconds = 15
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

function Write-Log {
    param([string]$Message)
    $ts = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    Write-Host "[$ts] $Message"
}

function Normalize-Thumbprint {
    param([string]$Thumbprint)
    (($Thumbprint -replace '\s','').Trim()).ToUpperInvariant()
}

function Get-CertificateFromStore {
    param(
        [string]$Thumbprint,
        [string]$StoreLocation,
        [string]$StoreName
    )

    $normalized = Normalize-Thumbprint $Thumbprint
    $storePath = "Cert:\$StoreLocation\$StoreName"

    $cert = Get-ChildItem -Path $storePath | Where-Object {
        (Normalize-Thumbprint $_.Thumbprint) -eq $normalized
    } | Select-Object -First 1

    if (-not $cert) {
        throw "Certificate with thumbprint '$Thumbprint' was not found in $storePath."
    }

    if (-not $cert.HasPrivateKey) {
        throw "Certificate '$($cert.Subject)' does not have an accessible private key."
    }

    return $cert
}

function Get-CertreqExe {
    $cmd = Get-Command certreq.exe -ErrorAction SilentlyContinue
    if ($cmd) { return $cmd.Source }

    $candidate = Join-Path $env:SystemRoot "System32\certreq.exe"
    if (Test-Path $candidate) { return $candidate }

    throw "certreq.exe was not found."
}

function New-SameKeyPkcs10Request {
    param(
        [System.Security.Cryptography.X509Certificates.X509Certificate2]$Certificate,
        [string]$StoreLocation
    )

    $context = if ([string]::Equals($StoreLocation, "LocalMachine", [System.StringComparison]::OrdinalIgnoreCase)) { 2 } else { 1 }

    $XCN_CRYPT_STRING_BASE64 = 1
    $XCN_CRYPT_STRING_BASE64REQUESTHEADER = 3
    $InheritPrivateKey = 3

    $certBase64 = [System.Convert]::ToBase64String($Certificate.RawData)

    $request = New-Object -ComObject X509Enrollment.CX509CertificateRequestPkcs10
    $request.Silent = $true
    $request.InitializeFromCertificate(
        $context,
        $certBase64,
        $XCN_CRYPT_STRING_BASE64,
        $InheritPrivateKey
    )
    $request.Encode()

    $enrollment = New-Object -ComObject X509Enrollment.CX509Enrollment
    $enrollment.InitializeFromRequest($request)

    return $enrollment.CreateRequest($XCN_CRYPT_STRING_BASE64REQUESTHEADER)
}

function ConvertTo-JsonBody {
    param(
        [string]$Serial,
        [string]$CsrPem
    )

    @{
        serial = $Serial
        csrPem = $CsrPem
    } | ConvertTo-Json -Depth 5 -Compress
}

function Invoke-RenewRequest {
    param(
        [string]$RenewUrl,
        [string]$BodyJson,
        [System.Security.Cryptography.X509Certificates.X509Certificate2]$ClientCertificate,
        [int]$TimeoutSeconds
    )

    Write-Log "Calling renew endpoint with existing client certificate: $RenewUrl"

    Add-Type -AssemblyName System.Net.Http

    $handler = New-Object System.Net.Http.HttpClientHandler
    $handler.ClientCertificateOptions = [System.Net.Http.ClientCertificateOption]::Manual
    $handler.ClientCertificates.Add($ClientCertificate)

    $client = New-Object System.Net.Http.HttpClient($handler)
    $client.Timeout = [TimeSpan]::FromSeconds([Math]::Max(5, $TimeoutSeconds))

    try {
        $content = New-Object System.Net.Http.StringContent($BodyJson, [System.Text.Encoding]::UTF8, "application/json")
        $response = $client.PostAsync($RenewUrl, $content).GetAwaiter().GetResult()
        $responseText = $response.Content.ReadAsStringAsync().GetAwaiter().GetResult()

        if (-not $response.IsSuccessStatusCode) {
            throw "Renew endpoint returned HTTP $([int]$response.StatusCode): $responseText"
        }

        return $responseText | ConvertFrom-Json
    }
    finally {
        if ($null -ne $content) { $content.Dispose() }
        $client.Dispose()
        $handler.Dispose()
    }
}

function Install-RenewedCertificate {
    param(
        [string]$CertificatePemPath,
        [string]$StoreLocation
    )

    $certreqExe = Get-CertreqExe
    Write-Log "Accepting renewed certificate with certreq."

    if ([string]::Equals($StoreLocation, "LocalMachine", [System.StringComparison]::OrdinalIgnoreCase)) {
        & $certreqExe -q -f -machine -accept $CertificatePemPath | Out-Null
    }
    else {
        & $certreqExe -q -f -user -accept $CertificatePemPath | Out-Null
    }

    if ($LASTEXITCODE -ne 0) {
        throw "certreq -accept failed with exit code $LASTEXITCODE."
    }
}

function Find-CertificateByThumbprint {
    param(
        [string]$Thumbprint,
        [string]$StoreLocation,
        [string]$StoreName
    )

    $normalized = Normalize-Thumbprint $Thumbprint
    $storePath = "Cert:\$StoreLocation\$StoreName"

    Get-ChildItem -Path $storePath | Where-Object {
        (Normalize-Thumbprint $_.Thumbprint) -eq $normalized
    } | Select-Object -First 1
}

function Find-NewCertificate {
    param(
        [System.Security.Cryptography.X509Certificates.X509Certificate2]$OldCert,
        [string]$ReturnedThumbprint,
        [string]$StoreLocation,
        [string]$StoreName
    )

    if ($ReturnedThumbprint) {
        $exact = Find-CertificateByThumbprint -Thumbprint $ReturnedThumbprint -StoreLocation $StoreLocation -StoreName $StoreName
        if ($exact) { return $exact }
    }

    $storePath = "Cert:\$StoreLocation\$StoreName"
    $oldThumb = Normalize-Thumbprint $OldCert.Thumbprint
    $subject = $OldCert.Subject

    Get-ChildItem -Path $storePath | Where-Object {
        $_.Subject -eq $subject -and
        (Normalize-Thumbprint $_.Thumbprint) -ne $oldThumb
    } | Sort-Object NotBefore -Descending | Select-Object -First 1
}

$workingDir = Join-Path $env:TEMP ("SmartPT-Renew-" + [Guid]::NewGuid().ToString("N"))
New-Item -ItemType Directory -Path $workingDir | Out-Null

try {
    $currentCert = Get-CertificateFromStore -Thumbprint $CurrentThumbprint -StoreLocation $StoreLocation -StoreName $StoreName

    Write-Log "Found current certificate: $($currentCert.Subject)"
    Write-Log "Current thumbprint: $($currentCert.Thumbprint)"
    Write-Log "Expires: $($currentCert.NotAfter.ToString("u"))"

    if ($currentCert.NotAfter -le (Get-Date)) {
        throw "The current certificate is already expired. Renew must happen before expiration."
    }

    $certificatePemPath = Join-Path $workingDir "renewed.crt"

    Write-Log "Generating PKCS#10 CSR from the existing certificate/private key."
    $csrPem = New-SameKeyPkcs10Request -Certificate $currentCert -StoreLocation $StoreLocation

    if (-not $csrPem -or ($csrPem -notmatch "BEGIN (NEW )?CERTIFICATE REQUEST")) {
        throw "PKCS#10 request generation failed or returned unexpected content."
    }

    $requestBodyJson = ConvertTo-JsonBody -Serial $Serial -CsrPem $csrPem
    $renewResponse = Invoke-RenewRequest `
        -RenewUrl $RenewUrl `
        -BodyJson $requestBodyJson `
        -ClientCertificate $currentCert `
        -TimeoutSeconds $RequestTimeoutSeconds

    if (-not $renewResponse) {
        throw "Renew endpoint returned an empty response."
    }

    if (-not $renewResponse.certificatePem) {
        $responseText = $renewResponse | ConvertTo-Json -Depth 10
        throw "Renew endpoint response did not contain certificatePem. Response: $responseText"
    }

    Set-Content -LiteralPath $certificatePemPath -Value $renewResponse.certificatePem -Encoding Ascii
    Install-RenewedCertificate -CertificatePemPath $certificatePemPath -StoreLocation $StoreLocation

    $newCert = Find-NewCertificate `
        -OldCert $currentCert `
        -ReturnedThumbprint $renewResponse.thumbprint `
        -StoreLocation $StoreLocation `
        -StoreName $StoreName

    [PSCustomObject]@{
        Success = $true
        Serial = $Serial
        OldThumbprint = $currentCert.Thumbprint
        NewThumbprint = if ($newCert) { $newCert.Thumbprint } else { $renewResponse.thumbprint }
        ExpiresAtUtc = $renewResponse.expiresAtUtc
        Operation = $renewResponse.operation
        RenewUrl = $RenewUrl
    } | ConvertTo-Json -Depth 5
}
finally {
    if (Test-Path $workingDir) {
        Remove-Item -LiteralPath $workingDir -Recurse -Force -ErrorAction SilentlyContinue
    }
}
