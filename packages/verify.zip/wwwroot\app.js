(function () {
  const apiBase = "api/verification";
  const params = new URLSearchParams(window.location.search);
  const challenge = params.get("challenge") || "";
  let redirectUrl = "/";

  const card = document.querySelector(".card");
  const subtitle = document.getElementById("subtitle");
  const message = document.getElementById("message");
  const wizardSteps = document.getElementById("wizard-steps");
  const enrollPanel = document.getElementById("enroll-panel");
  const verifyPanel = document.getElementById("verify-panel");
  const secretValue = document.getElementById("secret-value");
  const qrImage = document.getElementById("qr-image");
  const qrFallback = document.getElementById("qr-fallback");
  const verifyTitle = document.getElementById("verify-title");
  const verifySubtitle = document.getElementById("verify-subtitle");
  const backToEnrollButton = document.getElementById("back-to-enroll-button");
  const enrollButton = document.getElementById("enroll-button");
  const verifyButton = document.getElementById("verify-button");

  function showMessage(text) {
    message.textContent = text;
    message.classList.remove("hidden");
  }

  function clearMessage() {
    message.textContent = "";
    message.classList.add("hidden");
  }

  function setStep(step) {
    wizardSteps.classList.remove("hidden");
    [1, 2].forEach((value) => {
      const chip = document.getElementById(`step-chip-${value}`);
      chip.classList.toggle("active", value === step);
      chip.classList.toggle("done", value < step);
    });
  }

  function showPanels({ enroll = false, verify = false } = {}) {
    enrollPanel.classList.toggle("hidden", !enroll);
    verifyPanel.classList.toggle("hidden", !verify);
  }

  function setVerifyOnlyMode(enabled) {
    card.classList.toggle("verify-only", enabled);
    wizardSteps.classList.toggle("hidden", enabled);
  }

  async function api(path, options = {}) {
    const response = await fetch(path, {
      credentials: "include",
      headers: { "Content-Type": "application/json", ...(options.headers || {}) },
      ...options
    });
    const body = await response.json().catch(() => null);
    if (!response.ok) {
      throw new Error(body?.error || body?.message || `Request failed with ${response.status}`);
    }
    return body;
  }

  async function loadContext() {
    if (!challenge) {
      showMessage("Missing verification request.");
      return;
    }

    try {
      const context = await api(`${apiBase}/context?challenge=${encodeURIComponent(challenge)}`);
      if (context.disabled) {
        showMessage(context.message);
        return;
      }

      subtitle.textContent = `Verify access for ${context.displayName || context.principal}`;
      redirectUrl = context.returnUrl || "/";

      if (context.enrolled) {
        setVerifyOnlyMode(true);
        verifyTitle.textContent = "Verify access";
        verifySubtitle.textContent = "Enter the current code from your authenticator app to continue.";
        backToEnrollButton.classList.add("hidden");
        enrollButton.classList.add("hidden");
        verifyButton.classList.remove("hidden");
        verifyButton.textContent = "Continue";
        showPanels({ verify: true });
      } else {
        setVerifyOnlyMode(false);
        const enrollment = await api(`${apiBase}/enroll/start`, {
          method: "POST",
          body: JSON.stringify({ challenge })
        });
        secretValue.value = enrollment.secret || "";
        qrFallback.classList.add("hidden");
        qrImage.classList.add("hidden");
        qrImage.onerror = () => {
          qrImage.classList.add("hidden");
          qrFallback.classList.remove("hidden");
        };
        qrImage.onload = () => {
          qrFallback.classList.add("hidden");
          qrImage.classList.remove("hidden");
        };
        if (enrollment.qrUrl) {
          const separator = enrollment.qrUrl.includes("?") ? "&" : "?";
          const qrUrl = enrollment.qrUrl.startsWith("/")
            ? enrollment.qrUrl.substring(1)
            : enrollment.qrUrl;
          qrImage.src = `${qrUrl}${separator}v=${Date.now()}`;
        } else if (enrollment.qrDataUrl) {
          qrImage.src = enrollment.qrDataUrl;
        } else {
          qrFallback.classList.remove("hidden");
        }
        showPanels({ enroll: true });
        setStep(1);
      }
    } catch (error) {
      showMessage(error.message);
    }
  }

  document.getElementById("copy-secret-button").onclick = async () => {
    try {
      await navigator.clipboard.writeText(secretValue.value || "");
      showMessage("Setup key copied.");
    } catch {
      showMessage("Copy failed. Select and copy the key manually.");
    }
  };

  document.getElementById("go-to-verify-button").onclick = () => {
    clearMessage();
    verifyTitle.textContent = "Complete setup";
    verifySubtitle.textContent = "Enter the current code from your authenticator app to confirm the enrollment.";
    backToEnrollButton.classList.remove("hidden");
    enrollButton.classList.remove("hidden");
    verifyButton.classList.add("hidden");
    showPanels({ verify: true });
    setStep(2);
  };

  backToEnrollButton.onclick = () => {
    clearMessage();
    showPanels({ enroll: true });
    setStep(1);
  };

  enrollButton.onclick = async () => {
    try {
      const result = await api(`${apiBase}/enroll/complete`, {
        method: "POST",
        body: JSON.stringify({
          challenge,
          code: document.getElementById("verify-code").value
        })
      });
      window.location.assign(result.redirectUrl || redirectUrl);
    } catch (error) {
      showMessage(error.message);
    }
  };

  verifyButton.onclick = async () => {
    try {
      const result = await api(`${apiBase}/verify`, {
        method: "POST",
        body: JSON.stringify({
          challenge,
          code: document.getElementById("verify-code").value
        })
      });
      window.location.assign(result.redirectUrl || redirectUrl);
    } catch (error) {
      showMessage(error.message);
    }
  };

  loadContext();
})();
