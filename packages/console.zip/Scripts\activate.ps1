﻿param(
    [Parameter(Mandatory = $true)]
    [string]$Serial,

    [Parameter(Mandatory = $true)]
    [string]$DomainName,

    [string]$ActivateUrl = "https://api.smartpt.co.il/activate",

    [switch]$SkipRecycle
)

function Log($msg) {
    $ts = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss.fff")
    $line = "[$ts] $msg"
    Write-Host $line
    try {
        $logDir = "C:\ProgramData\SmartPT\logs"
        New-Item -ItemType Directory -Path $logDir -Force | Out-Null
        Add-Content -Path (Join-Path $logDir "activate-script.log") -Value $line
    }
    catch {
        # Do not fail activation because file logging is unavailable.
    }
}

function Fail($msg) {
    Log "ERROR: $msg"
    [Console]::Error.WriteLine($msg)
    exit 1
}

function Remove-JsonPropertyIfExists {
    param(
        [Parameter(Mandatory = $true)]
        [object]$Object,
        [Parameter(Mandatory = $true)]
        [string]$Name
    )

    if ($Object.PSObject.Properties.Name -contains $Name) {
        $Object.PSObject.Properties.Remove($Name)
    }
}

function Update-LicenseSettings {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Path,

        [Parameter(Mandatory = $true)]
        [string]$SerialValue,

        [Parameter(Mandatory = $true)]
        [string]$DomainValue
    )

    if (-not (Test-Path -LiteralPath $Path)) {
        Log "Skipping missing appsettings: $Path"
        return
    }

    $json = Get-Content -LiteralPath $Path -Raw | ConvertFrom-Json
    $licenseSection = $null

    if ($null -ne $json.License) {
        $licenseSection = $json.License
        $licenseSection.Serial = $SerialValue
        if ($licenseSection.PSObject.Properties.Name -contains "Domain") {
            $licenseSection.Domain = $DomainValue
        }
        else {
            $licenseSection | Add-Member -NotePropertyName "Domain" -NotePropertyValue $DomainValue
        }
        Remove-JsonPropertyIfExists -Object $licenseSection -Name "ClientCertificateThumbprint"
    }
    elseif ($null -ne $json.license) {
        $licenseSection = $json.license
        $licenseSection.serial = $SerialValue
        if ($licenseSection.PSObject.Properties.Name -contains "domain") {
            $licenseSection.domain = $DomainValue
        }
        else {
            $licenseSection | Add-Member -NotePropertyName "domain" -NotePropertyValue $DomainValue
        }
        Remove-JsonPropertyIfExists -Object $licenseSection -Name "clientCertificateThumbprint"
        Remove-JsonPropertyIfExists -Object $licenseSection -Name "ClientCertificateThumbprint"
    }
    elseif ($null -ne $json.SmartPtLicense) {
        $licenseSection = $json.SmartPtLicense
        $licenseSection.Serial = $SerialValue
        if ($licenseSection.PSObject.Properties.Name -contains "Domain") {
            $licenseSection.Domain = $DomainValue
        }
        else {
            $licenseSection | Add-Member -NotePropertyName "Domain" -NotePropertyValue $DomainValue
        }
        Remove-JsonPropertyIfExists -Object $licenseSection -Name "ClientCertificateThumbprint"
    }
    else {
        Log "Skipping unsupported appsettings structure: $Path"
        return
    }

    $json | ConvertTo-Json -Depth 20 | Set-Content -LiteralPath $Path -Encoding UTF8
    Log "Updated appsettings license serial/domain: $Path"
}

function Remove-IfExists {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Path
    )

    if (Test-Path -LiteralPath $Path) {
        Remove-Item -LiteralPath $Path -Force -ErrorAction SilentlyContinue
        Log "Removed stale runtime file: $Path"
    }
}

function Restart-SmartPTAppPools {
    $appcmd = Join-Path $env:WinDir "System32\inetsrv\appcmd.exe"
    $pools = @("SmartPT-Core", "PM-Backend", "JIT-Backend", "SA-Backend")

    foreach ($pool in $pools) {
        try {
            if (Test-Path -LiteralPath $appcmd) {
                & $appcmd recycle apppool /apppool.name:$pool | Out-Null
                Log "Recycled app pool via appcmd: $pool"
            }
            else {
                Import-Module WebAdministration -ErrorAction Stop
                Restart-WebAppPool -Name $pool -ErrorAction Stop
                Log "Recycled app pool via WebAdministration: $pool"
            }
        }
        catch {
            Log "WARNING: Failed to recycle app pool '$pool' - $($_.Exception.Message)"
        }
    }
}

function Invoke-ActivationApi {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Url,

        [Parameter(Mandatory = $true)]
        [string]$SerialValue,

        [Parameter(Mandatory = $true)]
        [string]$DomainValue
    )

    Log "Sending API-only activation request"
    Log "POST $Url"

    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    [System.Net.ServicePointManager]::Expect100Continue = $false
    [System.Net.WebRequest]::DefaultWebProxy = $null

    $body = @{
        serial = $SerialValue
        domain = $DomainValue
    } | ConvertTo-Json -Depth 4

    try {
        $request = [System.Net.HttpWebRequest]::Create($Url)
        $request.Method = "POST"
        $request.ContentType = "application/json"
        $request.Accept = "application/json"
        $request.Timeout = 30000
        $request.ReadWriteTimeout = 30000
        $request.ProtocolVersion = [Version]"1.1"
        $request.KeepAlive = $false

        $bytes = [System.Text.Encoding]::UTF8.GetBytes($body)
        $request.ContentLength = $bytes.Length

        $stream = $request.GetRequestStream()
        $stream.Write($bytes, 0, $bytes.Length)
        $stream.Close()

        $response = [System.Net.HttpWebResponse]$request.GetResponse()
        $reader = New-Object System.IO.StreamReader($response.GetResponseStream())
        $responseText = $reader.ReadToEnd()
        $reader.Close()

        Log "Activation API returned HTTP $([int]$response.StatusCode)"
        if (-not [string]::IsNullOrWhiteSpace($responseText)) {
            Log "Activation API response received"
        }
    }
    catch {
        $cleanMessage = $_.Exception.Message
        $webResponse = $_.Exception.Response

        if ($webResponse -is [System.Net.HttpWebResponse]) {
            $statusCode = [int]$webResponse.StatusCode
            $statusDescription = $webResponse.StatusDescription
            $responseText = $null

            try {
                $reader = New-Object System.IO.StreamReader($webResponse.GetResponseStream())
                $responseText = $reader.ReadToEnd()
                $reader.Close()
            }
            catch {
                $responseText = $null
            }

            if (-not [string]::IsNullOrWhiteSpace($responseText)) {
                try {
                    $errorJson = $responseText | ConvertFrom-Json
                    if ($errorJson.message) { $cleanMessage = [string]$errorJson.message }
                    elseif ($errorJson.error) { $cleanMessage = [string]$errorJson.error }
                    elseif ($errorJson.detail) { $cleanMessage = [string]$errorJson.detail }
                }
                catch {
                    $cleanMessage = $responseText.Trim()
                }
            }

            $statusLabel = if ([string]::IsNullOrWhiteSpace($statusDescription)) { "HTTP $statusCode" } else { "HTTP $statusCode $statusDescription" }
            Fail "Activation failed via $statusLabel. $cleanMessage"
        }

        Fail $cleanMessage
    }
}

$normalizedSerial = if ($null -eq $Serial) { "" } else { $Serial.Trim() }
$normalizedDomain = if ($null -eq $DomainName) { "" } else { $DomainName.Trim() }

if ([string]::IsNullOrWhiteSpace($normalizedSerial)) {
    Fail "License serial is required."
}

if ([string]::IsNullOrWhiteSpace($normalizedDomain)) {
    Fail "Domain name is required."
}

Log "=== SmartPT API-only activation started ==="

Invoke-ActivationApi -Url $ActivateUrl -SerialValue $normalizedSerial -DomainValue $normalizedDomain

$appSettingsPaths = @(
    "C:\inetpub\wwwroot\SmartPT-Core\Main\appsettings.json",
    "C:\inetpub\wwwroot\SmartPT-Core\MainSource\SmartPT.Core.MainApp\appsettings.json",
    "C:\inetpub\wwwroot\PM-Backend\Dev\Publish\appsettings.json",
    "C:\inetpub\wwwroot\PM-Backend\Dev\backend\SmartPT.AdDashboard\appsettings.json",
    "C:\inetpub\wwwroot\JIT-Backend\Dev\Publish\appsettings.json",
    "C:\inetpub\wwwroot\JIT-Backend\Dev\backend\SmartPT.AdDashboard\appsettings.json",
    "C:\inetpub\wwwroot\SA-Backend\Publish\appsettings.json",
    "C:\inetpub\wwwroot\SA-Backend\src\appsettings.json"
)

foreach ($path in $appSettingsPaths) {
    Update-LicenseSettings -Path $path -SerialValue $normalizedSerial -DomainValue $normalizedDomain
}

$staleRuntimeFiles = @(
    "C:\inetpub\wwwroot\SmartPT-Core\Main\state\license.state.json",
    "C:\inetpub\wwwroot\PM-Backend\Dev\Publish\config\license.json",
    "C:\inetpub\wwwroot\JIT-Backend\Dev\Publish\config\license.json"
)

foreach ($runtimeFile in $staleRuntimeFiles) {
    Remove-IfExists -Path $runtimeFile
}

if ($SkipRecycle) {
    Log "Skipping SmartPT IIS app pool recycle by request"
}
else {
    Restart-SmartPTAppPools
}

Log "=== SmartPT API-only activation completed successfully ==="

