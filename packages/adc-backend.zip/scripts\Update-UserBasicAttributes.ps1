param(
    [string] $InputJson,
    [string] $InputJsonBase64
)

try {
    Import-Module ActiveDirectory -ErrorAction Stop

    if (-not [string]::IsNullOrWhiteSpace($InputJsonBase64)) {
        $json = [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($InputJsonBase64))
    } else {
        $json = $InputJson
    }

    $input = $json | ConvertFrom-Json

    if (-not $input -or [string]::IsNullOrWhiteSpace($input.sam)) {
        $result = @{
            ok = $false
            error = "MISSING_INPUT"
        }
    } else {
        $replace = @{}
        $clear = @()

        $fieldMap = @{
            phone = "telephoneNumber"
            mobile = "mobile"
            email = "mail"
            title = "title"
            department = "department"
            company = "company"
            office = "physicalDeliveryOfficeName"
            description = "description"
        }

        foreach ($property in $fieldMap.Keys) {
            if ($null -ne $input.$property) {
                $value = [string]$input.$property
                $adField = $fieldMap[$property]
                if ([string]::IsNullOrWhiteSpace($value)) {
                    $clear += $adField
                } else {
                    $replace[$adField] = $value.Trim()
                }
            }
        }

        if ($replace.Count -gt 0) {
            Set-ADUser -Identity $input.sam -Replace $replace -ErrorAction Stop
        }

        if ($clear.Count -gt 0) {
            Set-ADUser -Identity $input.sam -Clear $clear -ErrorAction Stop
        }

        $result = @{
            ok = $true
        }
    }
} catch {
    $result = @{
        ok = $false
        error = $_.Exception.Message
    }
}

$result | ConvertTo-Json -Compress
