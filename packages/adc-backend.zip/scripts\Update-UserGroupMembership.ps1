param(
    [string] $InputJson,
    [string] $InputJsonBase64
)

try {
    Import-Module ActiveDirectory -ErrorAction Stop

    if (-not [string]::IsNullOrWhiteSpace($InputJsonBase64)) {
        $json = [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($InputJsonBase64))
    } else {
        $json = $InputJson
    }

    $input = $json | ConvertFrom-Json

    if (-not $input -or [string]::IsNullOrWhiteSpace($input.sam) -or [string]::IsNullOrWhiteSpace($input.group)) {
        $result = @{
            ok = $false
            error = "MISSING_INPUT"
        }
    } else {
        $action = ([string]$input.action).Trim().ToLowerInvariant()
        $groupName = ([string]$input.group).Trim()
        $group = Get-ADGroup -Identity $groupName -Properties Members -ErrorAction Stop
        $user = Get-ADUser -Identity $input.sam -ErrorAction Stop
        $userDn = $user.DistinguishedName
        $isMember = $group.Members -contains $userDn

        if ($action -eq "remove") {
            if (-not $isMember) {
                $result = @{
                    ok = $true
                    alreadyRemoved = $true
                }
            } else {
                Remove-ADGroupMember -Identity $group.DistinguishedName -Members $user.DistinguishedName -Confirm:$false -ErrorAction Stop
                $result = @{
                    ok = $true
                }
            }
        } else {
            if ($isMember) {
                $result = @{
                    ok = $true
                    alreadyMember = $true
                }
            } else {
                Add-ADGroupMember -Identity $group.DistinguishedName -Members $user.DistinguishedName -ErrorAction Stop
                $result = @{
                    ok = $true
                }
            }
        }
    }
} catch {
    $result = @{
        ok = $false
        error = $_.Exception.Message
    }
}

$result | ConvertTo-Json -Compress
