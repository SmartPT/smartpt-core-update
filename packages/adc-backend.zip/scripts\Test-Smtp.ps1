param(
    [string] $InputJson,
    [string] $InputJsonBase64
)

if (-not [string]::IsNullOrWhiteSpace($InputJsonBase64)) {
    $json = [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($InputJsonBase64))
} else {
    $json = $InputJson
}

$input = $json | ConvertFrom-Json

function Get-SmtpCredential($reference) {
    if (-not $reference) { return $null }
    try {
        if (Get-Command Get-StoredCredential -ErrorAction SilentlyContinue) {
            return (Get-StoredCredential -Target $reference)
        }
    } catch { }
    return $null
}

$steps = @{}

try {
    $smtp = $input.smtp
    if (-not $smtp.enabled) { throw "SMTP disabled" }

    if ($smtp.useTls -eq $true) {
        [System.Net.ServicePointManager]::ServerCertificateValidationCallback = { $true }
    }

    $client = New-Object System.Net.Mail.SmtpClient($smtp.host, [int]$smtp.port)
    $client.EnableSsl = [bool]$smtp.useTls
    $client.Timeout = [int]($smtp.timeoutSeconds * 1000)
    $steps.connect = "ok"

    if ($smtp.requireAuth -eq $true) {
        $cred = Get-SmtpCredential $smtp.credentialReference
        if (-not $cred) { throw "SMTP credentials not found" }
        $client.Credentials = New-Object System.Net.NetworkCredential($cred.Username, $cred.Password)
        $steps.auth = "ok"
    } else {
        $steps.auth = "skipped"
    }

    if ($smtp.useTls -eq $true) {
        $steps.tls = "ok"
    } else {
        $steps.tls = "skipped"
    }

    if ($input.sendTestEmail -eq $true) {
        $message = New-Object System.Net.Mail.MailMessage($input.from, $input.to, "SmartPT SMTP Diagnostics", "SMTP diagnostics test email.")
        $client.Send($message)
        $steps.send = "ok"
    } else {
        $steps.send = "skipped"
    }

    $result = $steps
} catch {
    if (-not $steps.connect) { $steps.connect = "failed" }
    if (-not $steps.tls) { $steps.tls = "unknown" }
    if (-not $steps.auth) { $steps.auth = "unknown" }
    if (-not $steps.send) { $steps.send = "failed" }

    $result = $steps
}

$result | ConvertTo-Json -Compress
